package com.techprimers.springbootwebsocketexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
@CrossOrigin(origins = "http://localhost:1841")
@SpringBootApplication
public class SpringBootWebsocketExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebsocketExampleApplication.class, args);
	}
}
